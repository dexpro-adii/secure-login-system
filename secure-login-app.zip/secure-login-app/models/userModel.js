const db = require('../db/database');

// NOTE: every query below uses '?' placeholders. better-sqlite3 sends the
// values separately from the SQL text, so user input can never be
// interpreted as part of the query. This is what prevents SQL injection —
// never build queries with string concatenation or template literals.

function createUser({ username, email, passwordHash }) {
  const stmt = db.prepare(
    'INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)'
  );
  const info = stmt.run(username, email, passwordHash);
  return info.lastInsertRowid;
}

function findByUsernameOrEmail(identifier) {
  const stmt = db.prepare(
    'SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1'
  );
  return stmt.get(identifier, identifier);
}

function findById(id) {
  const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
  return stmt.get(id);
}

function usernameOrEmailExists(username, email) {
  const stmt = db.prepare(
    'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1'
  );
  return stmt.get(username, email);
}

function setTotpSecret(userId, secret) {
  db.prepare('UPDATE users SET totp_secret = ? WHERE id = ?').run(secret, userId);
}

function enableTotp(userId) {
  db.prepare('UPDATE users SET totp_enabled = 1 WHERE id = ?').run(userId);
}

function disableTotp(userId) {
  db.prepare(
    'UPDATE users SET totp_enabled = 0, totp_secret = NULL WHERE id = ?'
  ).run(userId);
}

function recordFailedAttempt(userId) {
  db.prepare(
    'UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?'
  ).run(userId);
}

function resetFailedAttempts(userId) {
  db.prepare(
    'UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?'
  ).run(userId);
}

function lockAccount(userId, lockedUntilEpochMs) {
  db.prepare('UPDATE users SET locked_until = ? WHERE id = ?').run(
    lockedUntilEpochMs,
    userId
  );
}

function logLoginEvent({ userId, usernameAttempted, success, ip }) {
  db.prepare(
    'INSERT INTO login_events (user_id, username_attempted, success, ip) VALUES (?, ?, ?, ?)'
  ).run(userId || null, usernameAttempted, success ? 1 : 0, ip);
}

module.exports = {
  createUser,
  findByUsernameOrEmail,
  findById,
  usernameOrEmailExists,
  setTotpSecret,
  enableTotp,
  disableTotp,
  recordFailedAttempt,
  resetFailedAttempts,
  lockAccount,
  logLoginEvent,
};
