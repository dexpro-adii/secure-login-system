const express = require('express');
const bcrypt = require('bcrypt');
const speakeasy = require('speakeasy');
const qrcode = require('qrcode');

const userModel = require('../models/userModel');
const {
  registerRules,
  loginRules,
  totpTokenRules,
  handleValidation,
} = require('../middleware/validation');
const { requireAuth, requirePendingTotp } = require('../middleware/auth');

const router = express.Router();

const BCRYPT_COST_FACTOR = 12; // work factor; higher = slower to brute-force
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes

// ---------- Registration ----------

router.get('/register', (req, res) => {
  res.render('register', { errors: [], values: {} });
});

router.post(
  '/register',
  registerRules,
  handleValidation,
  async (req, res, next) => {
    try {
      if (req.validationErrors.length) {
        return res.status(400).render('register', {
          errors: req.validationErrors,
          values: { username: req.body.username, email: req.body.email },
        });
      }

      const { username, email, password } = req.body;

      // Existence check uses a parameterized query - the values are bound,
      // never concatenated into the SQL string.
      const existing = userModel.usernameOrEmailExists(username, email);
      if (existing) {
        return res.status(400).render('register', {
          errors: ['That username or email is already registered.'],
          values: { username, email },
        });
      }

      const passwordHash = await bcrypt.hash(password, BCRYPT_COST_FACTOR);
      userModel.createUser({ username, email, passwordHash });

      res.render('registerSuccess', { username });
    } catch (err) {
      next(err);
    }
  }
);

// ---------- Login ----------

router.get('/login', (req, res) => {
  res.render('login', { errors: [], values: {} });
});

router.post('/login', loginRules, handleValidation, async (req, res, next) => {
  try {
    if (req.validationErrors.length) {
      return res.status(400).render('login', {
        errors: req.validationErrors,
        values: { identifier: req.body.identifier },
      });
    }

    const { identifier, password } = req.body;
    const ip = req.ip;

    const user = userModel.findByUsernameOrEmail(identifier);

    // Generic error message for both "no such user" and "wrong password" -
    // this avoids leaking which usernames/emails exist (user enumeration).
    const genericError = 'Invalid username/email or password.';

    if (!user) {
      userModel.logLoginEvent({
        userId: null,
        usernameAttempted: identifier,
        success: false,
        ip,
      });
      return res
        .status(401)
        .render('login', { errors: [genericError], values: { identifier } });
    }

    if (user.locked_until && user.locked_until > Date.now()) {
      const minutesLeft = Math.ceil((user.locked_until - Date.now()) / 60000);
      return res.status(423).render('login', {
        errors: [
          `Account temporarily locked due to repeated failed attempts. Try again in ${minutesLeft} minute(s).`,
        ],
        values: { identifier },
      });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatches) {
      userModel.recordFailedAttempt(user.id);
      userModel.logLoginEvent({
        userId: user.id,
        usernameAttempted: identifier,
        success: false,
        ip,
      });

      const updated = userModel.findById(user.id);
      if (updated.failed_attempts >= MAX_FAILED_ATTEMPTS) {
        userModel.lockAccount(user.id, Date.now() + LOCKOUT_MS);
        return res.status(423).render('login', {
          errors: [
            'Too many failed attempts. Account locked for 15 minutes.',
          ],
          values: { identifier },
        });
      }

      return res
        .status(401)
        .render('login', { errors: [genericError], values: { identifier } });
    }

    // Password correct: reset lockout counters.
    userModel.resetFailedAttempts(user.id);

    // Regenerate the session on privilege change to prevent session fixation.
    req.session.regenerate((err) => {
      if (err) return next(err);

      if (user.totp_enabled) {
        // Password verified, but 2FA still required before full login.
        req.session.pendingTotpUserId = user.id;
        return res.redirect('/login/2fa');
      }

      req.session.userId = user.id;
      req.session.username = user.username;
      userModel.logLoginEvent({
        userId: user.id,
        usernameAttempted: identifier,
        success: true,
        ip,
      });
      return res.redirect('/dashboard');
    });
  } catch (err) {
    next(err);
  }
});

// ---------- 2FA: second factor at login ----------

router.get('/login/2fa', requirePendingTotp, (req, res) => {
  res.render('login2fa', { errors: [] });
});

router.post(
  '/login/2fa',
  requirePendingTotp,
  totpTokenRules,
  handleValidation,
  (req, res, next) => {
    try {
      if (req.validationErrors.length) {
        return res.status(400).render('login2fa', {
          errors: req.validationErrors,
        });
      }

      const userId = req.session.pendingTotpUserId;
      const user = userModel.findById(userId);
      if (!user) return res.redirect('/login');

      const verified = speakeasy.totp.verify({
        secret: user.totp_secret,
        encoding: 'base32',
        token: req.body.token,
        window: 1, // allow 1 step (30s) of clock drift
      });

      if (!verified) {
        userModel.logLoginEvent({
          userId: user.id,
          usernameAttempted: user.username,
          success: false,
          ip: req.ip,
        });
        return res
          .status(401)
          .render('login2fa', { errors: ['Invalid or expired code.'] });
      }

      req.session.regenerate((err) => {
        if (err) return next(err);
        req.session.userId = user.id;
        req.session.username = user.username;
        userModel.logLoginEvent({
          userId: user.id,
          usernameAttempted: user.username,
          success: true,
          ip: req.ip,
        });
        res.redirect('/dashboard');
      });
    } catch (err) {
      next(err);
    }
  }
);

// ---------- 2FA: enable/disable from account settings ----------

router.get('/2fa/setup', requireAuth, async (req, res, next) => {
  try {
    const user = userModel.findById(req.session.userId);
    const secret = speakeasy.generateSecret({
      name: `SecureLoginApp (${user.username})`,
    });

    // Stash the pending secret in the session until confirmed with a valid
    // code, so a half-finished setup can't lock the account into a broken
    // state.
    req.session.pendingTotpSecret = secret.base32;

    const qrDataUrl = await qrcode.toDataURL(secret.otpauth_url);
    res.render('twoFactorSetup', { qrDataUrl, secret: secret.base32, errors: [] });
  } catch (err) {
    next(err);
  }
});

router.post(
  '/2fa/setup',
  requireAuth,
  totpTokenRules,
  handleValidation,
  async (req, res, next) => {
    try {
      const pendingSecret = req.session.pendingTotpSecret;
      if (!pendingSecret) return res.redirect('/2fa/setup');

      if (req.validationErrors.length) {
        const qrDataUrl = await qrcode.toDataURL(
          speakeasy.otpauthURL({
            secret: pendingSecret,
            label: 'SecureLoginApp',
            encoding: 'base32',
          })
        );
        return res.status(400).render('twoFactorSetup', {
          qrDataUrl,
          secret: pendingSecret,
          errors: req.validationErrors,
        });
      }

      const verified = speakeasy.totp.verify({
        secret: pendingSecret,
        encoding: 'base32',
        token: req.body.token,
        window: 1,
      });

      if (!verified) {
        const qrDataUrl = await qrcode.toDataURL(
          speakeasy.otpauthURL({
            secret: pendingSecret,
            label: 'SecureLoginApp',
            encoding: 'base32',
          })
        );
        return res.status(400).render('twoFactorSetup', {
          qrDataUrl,
          secret: pendingSecret,
          errors: ['That code did not match. Please try again.'],
        });
      }

      userModel.setTotpSecret(req.session.userId, pendingSecret);
      userModel.enableTotp(req.session.userId);
      delete req.session.pendingTotpSecret;

      res.render('twoFactorEnabled');
    } catch (err) {
      next(err);
    }
  }
);

router.post('/2fa/disable', requireAuth, (req, res) => {
  userModel.disableTotp(req.session.userId);
  res.redirect('/dashboard');
});

// ---------- Dashboard & logout ----------

router.get('/dashboard', requireAuth, (req, res) => {
  const user = userModel.findById(req.session.userId);
  res.render('dashboard', { user });
});

router.post('/logout', (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('connect.sid');
    res.redirect('/login');
  });
});

module.exports = router;
