// Requires a fully authenticated session (password verified, and 2FA
// verified if the account has it enabled).
function requireAuth(req, res, next) {
  if (req.session && req.session.userId && !req.session.pendingTotpUserId) {
    return next();
  }
  return res.redirect('/login');
}

// Requires that a first-factor (password) login has happened and the
// account is now waiting on a TOTP code.
function requirePendingTotp(req, res, next) {
  if (req.session && req.session.pendingTotpUserId) {
    return next();
  }
  return res.redirect('/login');
}

module.exports = { requireAuth, requirePendingTotp };
