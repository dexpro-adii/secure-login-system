const { body, validationResult } = require('express-validator');

// All rules below sanitize (trim/escape/normalize) AND validate. Because the
// DB layer always uses parameterized queries, this validation is a defense
// against bad/malicious *content* (XSS, malformed data) rather than the last
// line of defense against SQL injection - that's handled structurally.

const registerRules = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be 3-30 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores')
    .escape(),
  body('email')
    .trim()
    .isEmail()
    .withMessage('A valid email is required')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 10 })
    .withMessage('Password must be at least 10 characters')
    .matches(/[a-z]/)
    .withMessage('Password must contain a lowercase letter')
    .matches(/[A-Z]/)
    .withMessage('Password must contain an uppercase letter')
    .matches(/[0-9]/)
    .withMessage('Password must contain a number'),
  body('confirmPassword').custom((value, { req }) => {
    if (value !== req.body.password) {
      throw new Error('Passwords do not match');
    }
    return true;
  }),
];

const loginRules = [
  body('identifier')
    .trim()
    .notEmpty()
    .withMessage('Username or email is required')
    .escape(),
  body('password').notEmpty().withMessage('Password is required'),
];

const totpTokenRules = [
  body('token')
    .trim()
    .isLength({ min: 6, max: 6 })
    .withMessage('Enter the 6-digit code')
    .isNumeric()
    .withMessage('Code must be numeric'),
];

// Collects express-validator results onto req.validationErrors and always
// calls next(). Route handlers check req.validationErrors themselves and
// re-render the form with messages when it's non-empty, instead of using
// next('route') (which would skip to an unrelated route, not a re-render).
function handleValidation(req, res, next) {
  const errors = validationResult(req);
  req.validationErrors = errors.isEmpty()
    ? []
    : errors.array().map((e) => e.msg);
  next();
}

module.exports = {
  registerRules,
  loginRules,
  totpTokenRules,
  handleValidation,
};
