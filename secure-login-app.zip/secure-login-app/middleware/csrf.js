const Tokens = require('csrf');
const tokens = new Tokens();

// Ensures every session has a CSRF secret, exposes a fresh token to views via
// res.locals.csrfToken, and rejects state-changing requests whose token
// doesn't match. This protects against Cross-Site Request Forgery: a
// malicious site can make the browser send a request, but it can't read the
// token out of our page to include it.
function csrfProtection(req, res, next) {
  if (!req.session.csrfSecret) {
    req.session.csrfSecret = tokens.secretSync();
  }
  res.locals.csrfToken = tokens.create(req.session.csrfSecret);

  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const submitted = req.body && req.body._csrf;
    if (!submitted || !tokens.verify(req.session.csrfSecret, submitted)) {
      return res.status(403).render('error', {
        message: 'Invalid or expired form submission. Please try again.',
      });
    }
  }
  next();
}

module.exports = csrfProtection;
