const rateLimit = require('express-rate-limit');

// Throttles brute-force guessing against auth endpoints. This is in addition
// to the per-account lockout logic in the login route.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many attempts from this device. Please try again later.',
});

module.exports = { authLimiter };
